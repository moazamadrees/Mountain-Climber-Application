import cv2
import mediapipe as mp
from PoseModule import poseDetector as PoseDetector
from tkinter import *
import tkinter as tk
from PIL import Image, ImageTk
import tkinter.messagebox


# class MainWindow():
#     def __init__(self, window, cap):
#         self.window = window
#         self.cap = cap
#         self.width = self.cap.get(cv2.CAP_PROP_FRAME_WIDTH)
#         self.height = self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
#         self.interval = 20 # Interval in ms to get the latest frame
#         # Create canvas for image
#         self.canvas = tk.Canvas(self.window, width=self.width, height=self.height)
#         self.canvas.place(x=200,y=200)
#         self.image = cv2.cvtColor(self.cap.read()[1], cv2.COLOR_BGR2RGB)
#         # Update image on canvas
#         self.update_image()
#     def update_image(self):
#         # Get the latest frame and convert image format
#         self.image = cv2.cvtColor(self.cap.read()[1], cv2.COLOR_BGR2RGB) # to RGB
#         self.image = Image.fromarray(self.image) # to PIL format
#         self.image = ImageTk.PhotoImage(self.image) # to ImageTk format
#         # Update image
#         self.canvas.create_image(0, 0, anchor=tk.NW, image=self.image)
#         # Repeat every 'interval' ms
#         self.window.after(self.interval, self.update_image)


# window=Tk()
# MainWindow(window, cv2.VideoCapture(0,cv2.CAP_DSHOW))
# window.mainloop()


#Window Creation
window=Tk()
window.title("Mountain Climber Counter")
width=window.winfo_screenwidth()
height=window.winfo_screenheight()
window.geometry("%dx%d" % (width, height))


#Background Image
bg_image=ImageTk.PhotoImage(file="logo.jpg")
x=Label(image=bg_image)
x.place(x=0,y=0)


#Instructions
instructions=Label(window,text="Mountain Climbers : One of the best exercises for Abs",font=("Raleway",20,"bold","italic"),bg="#e7e6d1")
instructions.place(x=350,y=0,height=30)


mpDraw = mp.solutions.mediapipe.python.solutions.drawing_utils
mpPose = mp.solutions.mediapipe.python.solutions.pose
pose = mpPose.Pose()
detector=PoseDetector()


#Open File Function
def openfile():
    feedback="Start"
    up = False
    form=0
    counter = 0
    filename=filedialog.askopenfilename(initialdir="/",title="Select a File",filetypes=(("mp4 files","*.mp4*"),("all files","*.*")))
    cap = cv2.VideoCapture(filename)
    while True:
        ret, img = cap.read() #640 x 480
        # #Determine dimensions of video - Help with creation of box in Line 43
        width  = cv2.CAP_PROP_FRAME_HEIGHT  # float `width`
        height = cv2.CAP_PROP_FRAME_WIDTH  # float `height`
        img = detector.findPose(img, False)
        lmList = detector.findPosition(img, False)
        imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        results = pose.process(imgRGB)
        

        if results.pose_landmarks:
            mpDraw.draw_landmarks(img, results.pose_landmarks, mpPose.POSE_CONNECTIONS)
            points = {}
            for id, lm in enumerate(results.pose_landmarks.landmark):
                h,w,c = img.shape
                cx, cy = int(lm.x*w), int(lm.y*h)
                points[id] = (cx,cy)


            leftangle=detector.findAngle(img,11,23,25)
            rightangle=detector.findAngle(img,12,24,26)
            elbow = detector.findAngle(img, 11, 13, 15)
            shoulder = detector.findAngle(img, 13, 11, 23)
            hip = detector.findAngle(img, 11, 23,25)


            cv2.circle(img, points[25], 15, (155,0,0), cv2.FILLED)
            cv2.circle(img, points[26], 15, (155,0,0), cv2.FILLED)
            cv2.circle(img, points[24], 15, (155,0,0), cv2.FILLED)
            cv2.circle(img, points[23], 15, (155,0,0), cv2.FILLED)


            if elbow > 160 and shoulder > 40 :
                form = 1
            if (form==1):
                if not up and points[26]<points[24]: 
                    feedback="UPR"
                    up = True
                    counter+=0.5

                if not up and points[25]<points[23]:
                    feedback="UPL"
                    up = True
                    counter+=0.5

                elif points[26]>points[24] and points[25]>points[23] :    
                    if 150>leftangle<120 and 150>rightangle<120:
                        feedback="Fix Form"
                    else:
                        print('Down')
                        up = False

        
        cv2.rectangle(img, (500, 0), (640, 40), (255, 255, 255), cv2.FILLED)
        cv2.putText(img, feedback, (500, 40 ), cv2.FONT_HERSHEY_PLAIN, 2,(0, 255, 0), 2)
        cv2.putText(img, str(counter), (100,150),cv2.FONT_HERSHEY_PLAIN, 12, (255,0,0),12)
        cv2.imshow("Press Q/q to Quit",img)
        if(cv2.waitKey(1) & 0xFF==ord('q')):
            break
    cap.release()
    cv2.destroyAllWindows()
    
    
#Webcam Function
def camvideo():
    feedback="Start"
    up = False
    form=0
    counter = 0
    cap = cv2.VideoCapture(0,cv2.CAP_DSHOW)
    # MainWindow(window, cap)
    while True:
        ret, img = cap.read() #640 x 480
        #Determine dimensions of video - Help with creation of box in Line 43
        width  = cv2.CAP_PROP_FRAME_HEIGHT  # float `width`
        height = cv2.CAP_PROP_FRAME_WIDTH  # float `height`
        img = detector.findPose(img, False)
        lmList = detector.findPosition(img, False)
        imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        results = pose.process(imgRGB)
        if results.pose_landmarks:
            mpDraw.draw_landmarks(img, results.pose_landmarks, mpPose.POSE_CONNECTIONS)
            points = {}
            for id, lm in enumerate(results.pose_landmarks.landmark):
                h,w,c = img.shape
                cx, cy = int(lm.x*w), int(lm.y*h)
                points[id] = (cx,cy)
            

            leftangle=detector.findAngle(img,11,23,25)
            rightangle=detector.findAngle(img,12,24,26)
            elbow = detector.findAngle(img, 11, 13, 15)
            shoulder = detector.findAngle(img, 13, 11, 23)
            hip = detector.findAngle(img, 11, 23,25)


            cv2.circle(img, points[25], 15, (155,0,0), cv2.FILLED)
            cv2.circle(img, points[26], 15, (155,0,0), cv2.FILLED)
            cv2.circle(img, points[24], 15, (155,0,0), cv2.FILLED)
            cv2.circle(img, points[23], 15, (155,0,0), cv2.FILLED)


            if elbow > 160 and shoulder > 40 :
                form = 1
            if (form==1):
                if not up and points[26]<points[24]: 
                    feedback="UPR"
                    up = True
                    counter+=0.5

                if not up and points[25]<points[23]:
                    feedback="UPL"
                    up = True
                    counter+=0.5

                elif points[26]>points[24] and points[25]>points[23] :    
                    if 150>leftangle<120 and 150>rightangle<120:
                        feedback="Fix Form"
                    else:
                        print('Down')
                        up = False

            
        cv2.rectangle(img, (500, 0), (640, 40), (255, 255, 255), cv2.FILLED)
        cv2.putText(img, feedback, (500, 40 ), cv2.FONT_HERSHEY_PLAIN, 2,(0, 255, 0), 2)        
        cv2.putText(img, str(counter), (100,150),cv2.FONT_HERSHEY_PLAIN, 12, (255,0,0),12)
        cv2.imshow("Press Q/q to Quit",img)
        if(cv2.waitKey(1) & 0xFF==ord('q')):
            break
    cap.release()
    cv2.destroyAllWindows()


#About the exercise Function
def about():
    cv2.destroyAllWindows()
    f = open("about.txt", "r")
    data=f.read()
    fx=Text(window,width=140,height=40,bg='#e7e6d1')
    fx.place(x=200,y=50)
    fx.insert(END,data)
    if keyboard.is_pressed('q'):
        fx.destroy()
    f.close()
    

#Meet the creators Function
def creators():
    tkinter.messagebox.showinfo("Creators Info","\nThis Program was made as\nSemester Project of CP-2 By:\n1.Moazam Adrees\n2.Taha Qazi \n")

    
#Exit Button
def close():
    window.quit()


explore=Button(window, text= "Open New File",bg='#e7e6d1', font=("Raleway",14,"bold","italic"), command=openfile).place(x=20,y=100)
livecam=Button(window, text="Open Web Camera",bg='#e7e6d1',font=("Raleway",14,"bold","italic"),command=camvideo).place(x=20,y=200)
about=Button(window, text= "About the Exercise",bg='#e7e6d1', font=("Raleway",14,"bold","italic"), command=about).place(x=20,y=300)
creators=Button(window, text= "The Creators",bg='#e7e6d1', font=("Raleway",14,"bold","italic"), command=creators).place(x=20,y=400)
close=Button(window, text= "Exit the Application",bg='#e7e6d1', font=("Raleway",14,"bold","italic"), command=close).place(x=20,y=500)


window.mainloop()